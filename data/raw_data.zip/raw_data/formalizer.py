import pandas as pd
import re
import numpy as np
import _pickle as pkl
from tqdm import tqdm


def regularize(data):
    # remove the head of the posters
    pattern = '\A([^\:\n]*\:[^\n]*\n)*\n'
    punc = '--+|__+|[\.,\\\[\]\(\)\{\}<>\?!~\|\&\:\'\"\^]'  # remove the continuously appeared -, _and.,\[](){}<>?!~|&:'"^
    email = '\w+@\w+(\w)*'
    data_len = data.shape[0]
    for i in tqdm(range(data_len)):
        p1 = re.sub(email, ' <email> ', re.sub(punc, "", re.sub(pattern, "", data.loc[i, 'data'])))
        p2 = re.sub(' [-_/] ', '  ', re.sub('\n', ' ', p1))  # remove '/n' and the isolated - _ /
        p3 = re.sub('[0-9][a-zA-Z]', lambda x: x.group()[0] + ' ' + x.group()[1], p2)
        if p3 is None or len(p3) == 0:
            p3 = '<empty>'
        data.loc[i, 'data'] = p3

    return data


def data_cleaning(train_data, test_data):
    raw_data = pd.concat([train_data, test_data], axis=0, ignore_index=True)
    data = np.array(raw_data['data'])

    global stop_words

    dic = dict({})
    fake_list = list([])
    print("---Building freq frequency...")
    for i, line in enumerate(data):
        try:
            line = line.split()
            for word in line:
                word = word.lower()
                try:
                    dic[word] += 1
                except:
                    dic[word] = 1
        except:
            fake_list.append(i)

    # remove the low frequent word (appears less than 5 times) then recount the vocabulary again
    # remove the stop words
    print("---Removing the low-frequency words and the stop words...")
    new_data = list([])
    for line in tqdm(data):
        line = line.split()
        list_line = list([])
        for word in line:
            word = word.lower()
            if word not in stop_words:
                if dic[word] > 5:
                    list_line.append(word)
                else:
                    list_line.append('<oov>')
        if len(list_line) == 0:
            list_line.append('<empty>')
        new_data.append(' '.join(list_line))

    print("---Generating csv...")
    n_train = train_data.shape[0]
    n_valid = n_train // 10
    new_train = new_data[0:n_train]
    new_test = new_data[n_train:]
    for i, new_str in enumerate(new_train):
        train_data.loc[i, 'data'] = new_str
    for i, new_str in enumerate(new_test):
        test_data.loc[i, 'data'] = new_str

    train_data.sample(frac=1).reset_index(drop=True)
    valid_data = train_data.loc[range(n_valid)]
    train_data = train_data.loc[range(n_valid, n_train)]
    return train_data, valid_data, test_data


def extract_features():
    global train_csv
    text = np.array(train_csv['data'])
    targets = np.array(train_csv['target'])
    VOCAB_SIZE = 31724
    MAX_FEATURE = 3000
    N_LABEL = 20
    N_DOC = train_csv.shape[0]

    # build a dict for each label and then a total dict
    print("---build a dict for each label and then a total dict")
    full_dict = {}
    label_dicts = [{} for i in range(N_LABEL)]
    label_count = [0] * N_LABEL
    for sample, label in zip(text, targets):
        label = int(label)
        label_count[label] += 1
        label_dict = label_dicts[label]
        sample = sample.split()
        word_bag = set(sample)
        for word in word_bag:
            if word in full_dict:
                full_dict[word] += 1
            else:
                full_dict[word] = 1

            if word in label_dict:
                label_dict[word] += 1
            else:
                label_dict[word] = 1

    feature_list = list([])
    for label, label_dict in enumerate(label_dicts):
        n_label = label_count[label]
        features = list(label_dict.items())
        sorted_features = list([])
        for item in features:
            word, in_count = item
            in_freq = in_count / n_label
            out_freq = full_dict[word] / VOCAB_SIZE
            sorted_features.append((word, np.log(in_freq / out_freq)))
        sorted_features.sort(key=lambda x: x[1], reverse=True)
        end = min(MAX_FEATURE, len(sorted_features))
        features = np.asarray(sorted_features[:end]).transpose()[0].tolist()
        if len(features) < N_LABEL:
            features = features + [0] * (N_LABEL-len(features))
        feature_list.append(features)

    return feature_list

stop_words = ["'d", "'ll", "'m", "'re", "'s", "'t", "'ve", 'ZT', 'ZZ', 'a', "a's", 'able', 'about', 'above', 'abst', 'accordance', 'according', 'accordingly', 'across', 'act', 'actually', 'added', 'adj', 'adopted', 'affected', 'affecting', 'affects', 'after', 'afterwards', 'again', 'against', 'ah', "ain't", 'all', 'allow', 'allows', 'almost', 'alone', 'along', 'already', 'also', 'although', 'always', 'am', 'among', 'amongst', 'an', 'and', 'announce', 'another', 'any', 'anybody', 'anyhow', 'anymore', 'anyone', 'anything', 'anyway', 'anyways', 'anywhere', 'apart', 'apparently', 'appear', 'appreciate', 'appropriate', 'approximately', 'are', 'area', 'areas', 'aren', "aren't", 'arent', 'arise', 'around', 'as', 'aside', 'ask', 'asked', 'asking', 'asks', 'associated', 'at', 'auth', 'available', 'away', 'awfully', 'b', 'back', 'backed', 'backing', 'backs', 'be', 'became', 'because', 'become', 'becomes', 'becoming', 'been', 'before', 'beforehand', 'began', 'begin', 'beginning', 'beginnings', 'begins', 'behind', 'being', 'beings', 'believe', 'below', 'beside', 'besides', 'best', 'better', 'between', 'beyond', 'big', 'biol', 'both', 'brief', 'briefly', 'but', 'by', 'c', "c'mon", "c's", 'ca', 'came', 'can', "can't", 'cannot', 'cant', 'case', 'cases', 'cause', 'causes', 'certain', 'certainly', 'changes', 'clear', 'clearly', 'co', 'com', 'come', 'comes', 'concerning', 'consequently', 'consider', 'considering', 'contain', 'containing', 'contains', 'corresponding', 'could', "couldn't", 'couldnt', 'course', 'currently', 'd', 'date', 'definitely', 'describe', 'described', 'despite', 'did', "didn't", 'differ', 'different', 'differently', 'discuss', 'do', 'does', "doesn't", 'doing', "don't", 'done', 'down', 'downed', 'downing', 'downs', 'downwards', 'due', 'during', 'e', 'each', 'early', 'ed', 'edu', 'effect', 'eg', 'eight', 'eighty', 'either', 'else', 'elsewhere', 'end', 'ended', 'ending', 'ends', 'enough', 'entirely', 'especially', 'et', 'et-al', 'etc', 'even', 'evenly', 'ever', 'every', 'everybody', 'everyone', 'everything', 'everywhere', 'ex', 'exactly', 'example', 'except', 'f', 'face', 'faces', 'fact', 'facts', 'far', 'felt', 'few', 'ff', 'fifth', 'find', 'finds', 'first', 'five', 'fix', 'followed', 'following', 'follows', 'for', 'former', 'formerly', 'forth', 'found', 'four', 'from', 'full', 'fully', 'further', 'furthered', 'furthering', 'furthermore', 'furthers', 'g', 'gave', 'general', 'generally', 'get', 'gets', 'getting', 'give', 'given', 'gives', 'giving', 'go', 'goes', 'going', 'gone', 'good', 'goods', 'got', 'gotten', 'great', 'greater', 'greatest', 'greetings', 'group', 'grouped', 'grouping', 'groups', 'h', 'had', "hadn't", 'happens', 'hardly', 'has', "hasn't", 'have', "haven't", 'having', 'he', "he's", 'hed', 'hello', 'help', 'hence', 'her', 'here', "here's", 'hereafter', 'hereby', 'herein', 'heres', 'hereupon', 'hers', 'herself', 'hes', 'hi', 'hid', 'high', 'higher', 'highest', 'him', 'himself', 'his', 'hither', 'home', 'hopefully', 'how', 'howbeit', 'however', 'hundred', 'i', "i'd", "i'll", "i'm", "i've", 'id', 'ie', 'if', 'ignored', 'im', 'immediate', 'immediately', 'importance', 'important', 'in', 'inasmuch', 'inc', 'include', 'indeed', 'index', 'indicate', 'indicated', 'indicates', 'information', 'inner', 'insofar', 'instead', 'interest', 'interested', 'interesting', 'interests', 'into', 'invention', 'inward', 'is', "isn't", 'it', "it'd", "it'll", "it's", 'itd', 'its', 'itself', 'j', 'just', 'k', 'keep', 'keeps', 'kept', 'keys', 'kg', 'kind', 'km', 'knew', 'know', 'known', 'knows', 'l', 'large', 'largely', 'last', 'lately', 'later', 'latest', 'latter', 'latterly', 'least', 'less', 'lest', 'let', "let's", 'lets', 'like', 'liked', 'likely', 'line', 'little', 'long', 'longer', 'longest', 'look', 'looking', 'looks', 'ltd', 'm', 'made', 'mainly', 'make', 'makes', 'making', 'man', 'many', 'may', 'maybe', 'me', 'mean', 'means', 'meantime', 'meanwhile', 'member', 'members', 'men', 'merely', 'mg', 'might', 'million', 'miss', 'ml', 'more', 'moreover', 'most', 'mostly', 'mr', 'mrs', 'much', 'mug', 'must', 'my', 'myself', 'n', "n't", 'na', 'name', 'namely', 'nay', 'nd', 'near', 'nearly', 'necessarily', 'necessary', 'need', 'needed', 'needing', 'needs', 'neither', 'never', 'nevertheless', 'new', 'newer', 'newest', 'next', 'nine', 'ninety', 'no', 'nobody', 'non', 'none', 'nonetheless', 'noone', 'nor', 'normally', 'nos', 'not', 'noted', 'nothing', 'novel', 'now', 'nowhere', 'number', 'numbers', 'o', 'obtain', 'obtained', 'obviously', 'of', 'off', 'often', 'oh', 'ok', 'okay', 'old', 'older', 'oldest', 'omitted', 'on', 'once', 'one', 'ones', 'only', 'onto', 'open', 'opened', 'opening', 'opens', 'or', 'ord', 'order', 'ordered', 'ordering', 'orders', 'other', 'others', 'otherwise', 'ought', 'our', 'ours', 'ourselves', 'out', 'outside', 'over', 'overall', 'owing', 'own', 'p', 'page', 'pages', 'part', 'parted', 'particular', 'particularly', 'parting', 'parts', 'past', 'per', 'perhaps', 'place', 'placed', 'places', 'please', 'plus', 'point', 'pointed', 'pointing', 'points', 'poorly', 'possible', 'possibly', 'potentially', 'pp', 'predominantly', 'present', 'presented', 'presenting', 'presents', 'presumably', 'previously', 'primarily', 'probably', 'problem', 'problems', 'promptly', 'proud', 'provides', 'put', 'puts', 'q', 'que', 'quickly', 'quite', 'qv', 'r', 'ran', 'rather', 'rd', 're', 'readily', 'really', 'reasonably', 'recent', 'recently', 'ref', 'refs', 'regarding', 'regardless', 'regards', 'related', 'relatively', 'research', 'respectively', 'resulted', 'resulting', 'results', 'right', 'room', 'rooms', 'run', 's', 'said', 'same', 'saw', 'say', 'saying', 'says', 'sec', 'second', 'secondly', 'seconds', 'section', 'see', 'seeing', 'seem', 'seemed', 'seeming', 'seems', 'seen', 'sees', 'self', 'selves', 'sensible', 'sent', 'serious', 'seriously', 'seven', 'several', 'shall', 'she', "she'll", 'shed', 'shes', 'should', "shouldn't", 'show', 'showed', 'showing', 'shown', 'showns', 'shows', 'side', 'sides', 'significant', 'significantly', 'similar', 'similarly', 'since', 'six', 'slightly', 'small', 'smaller', 'smallest', 'so', 'some', 'somebody', 'somehow', 'someone', 'somethan', 'something', 'sometime', 'sometimes', 'somewhat', 'somewhere', 'soon', 'sorry', 'specifically', 'specified', 'specify', 'specifying', 'state', 'states', 'still', 'stop', 'strongly', 'sub', 'substantially', 'successfully', 'such', 'sufficiently', 'suggest', 'sup', 'sure', 't', "t's", 'take', 'taken', 'taking', 'tell', 'tends', 'th', 'than', 'thank', 'thanks', 'thanx', 'that', "that'll", "that's", "that've", 'thats', 'the', 'their', 'theirs', 'them', 'themselves', 'then', 'thence', 'there', "there'll", "there's", "there've", 'thereafter', 'thereby', 'thered', 'therefore', 'therein', 'thereof', 'therere', 'theres', 'thereto', 'thereupon', 'these', 'they', "they'd", "they'll", "they're", "they've", 'theyd', 'theyre', 'thing', 'things', 'think', 'thinks', 'third', 'this', 'thorough', 'thoroughly', 'those', 'thou', 'though', 'thoughh', 'thought', 'thoughts', 'thousand', 'three', 'throug', 'through', 'throughout', 'thru', 'thus', 'til', 'tip', 'to', 'today', 'together', 'too', 'took', 'toward', 'towards', 'tried', 'tries', 'truly', 'try', 'trying', 'ts', 'turn', 'turned', 'turning', 'turns', 'twice', 'two', 'u', 'un', 'under', 'unfortunately', 'unless', 'unlike', 'unlikely', 'until', 'unto', 'up', 'upon', 'ups', 'us', 'use', 'used', 'useful', 'usefully', 'usefulness', 'uses', 'using', 'usually', 'uucp', 'v', 'value', 'various', 'very', 'via', 'viz', 'vol', 'vols', 'vs', 'w', 'want', 'wanted', 'wanting', 'wants', 'was', "wasn't", 'way', 'ways', 'we', "we'd", "we'll", "we're", "we've", 'wed', 'welcome', 'well', 'wells', 'went', 'were', "weren't", 'what', "what'll", "what's", 'whatever', 'whats', 'when', 'whence', 'whenever', 'where', "where's", 'whereafter', 'whereas', 'whereby', 'wherein', 'wheres', 'whereupon', 'wherever', 'whether', 'which', 'while', 'whim', 'whither', 'who', "who'll", "who's", 'whod', 'whoever', 'whole', 'whom', 'whomever', 'whos', 'whose', 'why', 'widely', 'will', 'willing', 'wish', 'with', 'within', 'without', "won't", 'wonder', 'words', 'work', 'worked', 'working', 'works', 'world', 'would', "wouldn't", 'www', 'x', 'y', 'year', 'years', 'yes', 'yet', 'you', "you'd", "you'll", "you're", "you've", 'youd', 'young', 'younger', 'youngest', 'your', 'youre', 'yours', 'yourself', 'yourselves', 'z', 'zero', 'zt', 'zz']

print("Regularizing the training data...")
raw_train_data = regularize(pd.read_csv('train.csv'))
print("Regularizing the test data...")
raw_test_data = regularize(pd.read_csv('test.csv'))

print("Cleaning the data...")
train_csv, valid_csv, test_csv = data_cleaning(raw_train_data, raw_test_data)

del raw_test_data
del raw_train_data

train_csv.to_csv('clean_train.csv', index=False)
valid_csv.to_csv('clean_valid.csv', index=False)
test_csv.to_csv('clean_test.csv', index=False)
print("Data written complete.")
del test_csv
del valid_csv

print("Building features...")
feature_list = extract_features()
with open("features.pkl", 'wb') as file:
    pkl.dump(feature_list, file)
